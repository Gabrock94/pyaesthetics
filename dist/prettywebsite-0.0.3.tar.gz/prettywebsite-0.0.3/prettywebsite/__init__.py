from . import quadTreeDecomposition
from . import colorfulness
from . import brightness
from . import symmetry
from . import faceDetection
from . import analysis

# This is used to print out the package version
__version__ = '0.0.3' #Version Control


