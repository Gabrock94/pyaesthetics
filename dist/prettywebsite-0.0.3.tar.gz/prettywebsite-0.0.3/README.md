# PrettyWebsites
A python package for aesthetic analysis of web pages.

[![Documentation Status](https://readthedocs.org/projects/prettywebsite/badge/?version=latest)](http://prettywebsite.readthedocs.io/en/latest/?badge=latest)
