# PrettyWebsites
A python package for the Aesthetic Analysis of Web Pages (or just any image, we are not racists).

![GitHub release](https://img.shields.io/github/release/Gabrock94/prettywebsite.svg)
[![PyPI](https://img.shields.io/pypi/v/prettywebsite.svg)](https://badge.fury.io/py/prettywebsite)
[![PyPI pyversions](https://img.shields.io/pypi/pyversions/prettywebsite.svg)](https://pypi.python.org/pypi/prettywebsite/)
[![PyPI status](https://img.shields.io/pypi/status/prettywebsite.svg)](https://pypi.python.org/pypi/prettywebsite/)
[![Documentation Status](https://readthedocs.org/projects/prettywebsite/badge/?version=latest)](http://prettywebsite.readthedocs.io/en/latest/?badge=latest)
[![DOI](https://zenodo.org/badge/129248933.svg)](https://zenodo.org/badge/latestdoi/129248933)


